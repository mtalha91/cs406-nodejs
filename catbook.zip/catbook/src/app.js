/*const http = require('http');

const server = http.createServer(function(request, response){
	//response.end('Hello world NodeJS Server!');
	response.end('Hello world NodeJS Server with Nodemon!');
});

const port = 3000;
server.listen(port, function(){
	console.log('Server running on port' + port);
});
*/
//Express code
/*
const http = require('http');

let express = require('express')
let app = express();

app.get('/', (req, res) => res.send('Hello World with Express'));

const port = 3000;
app.listen(port, function(){
	console.log('Server running on port' + port);
});
*/
//Express code with HTML

const http = require('http');

let express = require('express')
let app = express();

//app.use('/static', express.static('public'));

app.get('/', (req, res) => res.sendFile('index.html', {root: 'src/views'}));

const port = 3000;
app.listen(port, function(){
	console.log('Server running on port' + port);
});