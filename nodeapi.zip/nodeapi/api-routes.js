// api-routes.js

let router = require('express').Router();
router.get('/', function (req, res) {
    res.json({
        status: 'API Its Working',
        message: 'Welcome to RESTHub crafted with love!',
    });
});

router.get('/contact/:contactid', function (req, res) {
    res.json({
		"name":"John",
		"age":30,
		"cars":[ "Ford", "BMW", "Fiat" ]
	});
});

router.post('/contact', function (req, res) {
    res.json({
        status: '200',
        message: 'Data is save successfully!',
    });
});

router.delete('/contact/:contactid', function (req, res) {
    res.json({
        status: '200',
        message: 'Data is deleted successfully!',
    });
});

router.put('/contact/:contactid', function (req, res) {
    res.json({
        status: '200',
        message: 'Data is updated successfully!',
    });
});

module.exports = router;